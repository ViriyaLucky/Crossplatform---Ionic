# UTS-Crossplatform

Nama: Viriya Lucky
NIM: 00000019700 - Kelas: A

Vercel Link:
https://uts-viriyalucky-19700.vercel.app/