import { Product } from './product.model';

export interface Ram extends Product{
    speed: number,
    ukuran:number
}